<!DOCTYPE html>
<html>
<head>
 <style type="text/css">
   #t{
    
    width: 500px;
    height: 30px;
    background-color: #D3D3D3;
   }
   #b{
    width: 300px;
    height:50px;
   }
 </style>
</head>
<body>

  <form method="POST" >
   <center> <input id="t" type="text" placeholder="Enter Email" name="email" required></center><br>
  <center>  <input id="b" type="submit" value="submit" name="valid"></center>
  </form>

 <?php




if(array_key_exists('valid',$_POST)){ 
  $email = $_POST['email'];

  if(strlen($email) >= 20){
     echo"nor more than qo character"; }

  else{

  $var1 = explode('@', $email);

  if (sizeof($var1) > 2)
    echo "Email  contain only \"@\" - try again!";
  elseif(sizeof($var1) <= 1 )
    echo "Email must contain \"@\" - try again! ";

  else{

    if( is_numeric(substr($var1[0], 0, 1)))
      echo "First character is alphabet!";

    else{
      
      if(preg_match('/\s/', $email))
        echo "not contain spaces - try again!";

      else{
        
        $var2 = explode(".", $email);
        if(sizeof($var2) > 3)
          echo " use .com, .edu.pk, or co.uk instead.";
        elseif(sizeof($var2) <= 1)
          echo "Email contains no domain - try agan!";
        elseif(sizeof($var2) == 2){
          if($var2[1] == "com"){
            echo "<b>Email is correct!</b>";
          }
          else
            echo " use .com, .edu.pk, or co.uk instead.";
        }
        elseif(sizeof($var2) == 3){
          if($var2[1] == "edu" && $var2[2] == "pk")
            echo "<b>Email is correct!</b>";
          elseif($var2 == "co" && $var2 == "uk")
            echo "<b>Email is correct!</b>";
          else{
            echo " use .com, .edu.pk, or co.uk instead.";
          }

        }

      }

    }

}

} 
}


?>



</body>
</html>